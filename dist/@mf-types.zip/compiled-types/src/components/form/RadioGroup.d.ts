interface RadioGroupProps {
    legend: string;
    options: {
        id: string;
    }[];
}
declare const RadioGroup: React.FC<RadioGroupProps>;
export default RadioGroup;
