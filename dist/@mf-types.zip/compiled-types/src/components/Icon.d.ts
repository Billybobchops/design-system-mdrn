interface IconProps {
    fill?: string;
}
export declare const ICFooterLogo: React.FC<IconProps>;
export declare const AutoPay: React.FC<IconProps>;
export declare const Paperless: React.FC<IconProps>;
export declare const PayByText: React.FC<IconProps>;
export declare const ChevronLarge: React.FC<IconProps>;
export declare const Minus: React.FC<IconProps>;
export declare const Plus: React.FC<IconProps>;
export declare const Info: React.FC<IconProps>;
export declare const MenuClose: React.FC<IconProps>;
export declare const MenuCloseLarge: React.FC<IconProps>;
export declare const ErrorIcon: React.FC<IconProps>;
export declare const ErrorLarge: React.FC<IconProps>;
export declare const Success: React.FC<IconProps>;
export declare const Chevron: React.FC<IconProps>;
export declare const Search: React.FC<IconProps>;
export declare const Remove: React.FC<IconProps>;
export declare const NewWindow: React.FC<IconProps>;
export declare const Warning: React.FC<IconProps>;
export declare const WarningLarge: React.FC<IconProps>;
export declare const SelectChevron: React.FC<IconProps>;
export declare const DropdownChevron: React.FC<IconProps>;
export {};
