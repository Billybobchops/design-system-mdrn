interface ParagraphProps {
    children: React.ReactNode;
}
declare const Paragraph: React.FC<ParagraphProps>;
export default Paragraph;
