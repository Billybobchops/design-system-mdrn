interface UnorderedListProps {
    items: string[];
}
declare const UnorderedList: React.FC<UnorderedListProps>;
export default UnorderedList;
