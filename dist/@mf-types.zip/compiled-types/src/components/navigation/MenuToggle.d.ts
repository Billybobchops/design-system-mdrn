interface MenuToggleProps {
    isOpen: boolean;
}
declare const MenuToggle: React.FC<MenuToggleProps>;
export default MenuToggle;
