export * from './compiled-types/src/components/tabular/Tab';
export { default } from './compiled-types/src/components/tabular/Tab';