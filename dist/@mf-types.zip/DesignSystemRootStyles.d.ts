export * from './compiled-types/src/styles/design-system-styles';
export { default } from './compiled-types/src/styles/design-system-styles';