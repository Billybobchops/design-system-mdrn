export * from './compiled-types/src/components/form/Label';
export { default } from './compiled-types/src/components/form/Label';