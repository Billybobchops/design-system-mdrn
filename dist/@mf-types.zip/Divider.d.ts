export * from './compiled-types/src/components/Divider';
export { default } from './compiled-types/src/components/Divider';