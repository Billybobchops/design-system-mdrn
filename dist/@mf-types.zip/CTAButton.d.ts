export * from './compiled-types/src/components/button/CTAButton';
export { default } from './compiled-types/src/components/button/CTAButton';