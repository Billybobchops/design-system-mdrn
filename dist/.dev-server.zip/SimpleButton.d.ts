export * from './compiled-types/src/components/button/SimpleButton';
export { default } from './compiled-types/src/components/button/SimpleButton';