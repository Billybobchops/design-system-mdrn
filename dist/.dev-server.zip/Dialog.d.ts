export * from './compiled-types/src/components/Dialog';
export { default } from './compiled-types/src/components/Dialog';