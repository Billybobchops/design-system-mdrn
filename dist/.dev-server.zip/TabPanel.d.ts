export * from './compiled-types/src/components/tabular/TabPanel';
export { default } from './compiled-types/src/components/tabular/TabPanel';