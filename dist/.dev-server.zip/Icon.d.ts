export * from './compiled-types/src/components/Icon';
export { default } from './compiled-types/src/components/Icon';