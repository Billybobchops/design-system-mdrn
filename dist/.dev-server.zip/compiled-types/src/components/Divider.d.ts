interface DividerProps {
    isDark: boolean;
}
declare const Divider: React.FC<DividerProps>;
export default Divider;
