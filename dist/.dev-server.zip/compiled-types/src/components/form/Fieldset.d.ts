interface FieldsetProps {
    legend: string;
    children?: React.ReactNode;
}
declare const Fieldset: React.FC<FieldsetProps>;
export default Fieldset;
