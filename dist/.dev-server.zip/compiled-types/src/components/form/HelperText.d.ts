interface HelperTextProps {
    helperID: string;
    helperText: string;
}
declare const HelperText: React.FC<HelperTextProps>;
export default HelperText;
