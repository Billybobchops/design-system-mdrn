interface IconParagraphProps {
    content: string;
    icon: React.ReactNode;
}
declare const IconParagraph: React.FC<IconParagraphProps>;
export default IconParagraph;
