interface TabPanelProps {
    children: React.ReactNode;
    tab: string;
}
declare const TabPanel: React.FC<TabPanelProps>;
export default TabPanel;
