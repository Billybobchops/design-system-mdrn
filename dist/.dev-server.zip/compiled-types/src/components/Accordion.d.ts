interface AccordionProps {
    children?: React.ReactNode;
    title: string;
}
declare const Accordion: React.FC<AccordionProps>;
export default Accordion;
