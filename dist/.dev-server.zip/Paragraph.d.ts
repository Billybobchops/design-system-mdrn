export * from './compiled-types/src/components/typography/Paragraph';
export { default } from './compiled-types/src/components/typography/Paragraph';