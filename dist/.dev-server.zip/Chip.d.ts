export * from './compiled-types/src/components/Chip';
export { default } from './compiled-types/src/components/Chip';