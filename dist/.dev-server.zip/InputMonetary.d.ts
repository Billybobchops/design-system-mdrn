export * from './compiled-types/src/components/form/InputMonetary';
export { default } from './compiled-types/src/components/form/InputMonetary';