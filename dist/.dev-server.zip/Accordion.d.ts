export * from './compiled-types/src/components/Accordion';
export { default } from './compiled-types/src/components/Accordion';