export * from './compiled-types/src/components/InlineLink';
export { default } from './compiled-types/src/components/InlineLink';