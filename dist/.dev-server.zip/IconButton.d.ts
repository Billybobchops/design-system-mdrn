export * from './compiled-types/src/components/button/IconButton';
export { default } from './compiled-types/src/components/button/IconButton';