export * from './compiled-types/src/components/Badge';
export { default } from './compiled-types/src/components/Badge';