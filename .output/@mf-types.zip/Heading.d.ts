export * from './compiled-types/src/components/typography/Heading';
export { default } from './compiled-types/src/components/typography/Heading';