interface ChipProps {
    title: string;
    onRemove: () => void;
}
declare const Chip: React.FC<ChipProps>;
export default Chip;
