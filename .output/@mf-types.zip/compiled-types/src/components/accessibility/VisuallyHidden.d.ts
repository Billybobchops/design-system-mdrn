interface VisuallyHiddenProps {
    children: React.ReactNode;
}
declare const VisuallyHidden: React.FC<VisuallyHiddenProps>;
export default VisuallyHidden;
