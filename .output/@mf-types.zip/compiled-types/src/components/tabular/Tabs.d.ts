interface TabsProps {
    children: React.ReactNode;
    defaultSelectedTab: string;
}
declare const Tabs: React.FC<TabsProps>;
export default Tabs;
