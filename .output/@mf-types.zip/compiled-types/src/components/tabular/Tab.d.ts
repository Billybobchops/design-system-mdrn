interface TabProps {
    children: React.ReactNode;
    tab: string;
}
declare const Tab: React.FC<TabProps>;
export default Tab;
