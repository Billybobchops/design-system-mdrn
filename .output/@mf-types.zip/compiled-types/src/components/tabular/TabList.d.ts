interface TabListProps {
    children: React.ReactNode;
    ariaLabel: string;
}
declare const TabList: React.FC<TabListProps>;
export default TabList;
