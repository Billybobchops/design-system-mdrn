interface InputMonetaryProps {
    disabled?: boolean;
    helperText?: string;
    label: string;
    name: string;
    required: boolean;
}
declare const InputMonetary: React.FC<InputMonetaryProps>;
export default InputMonetary;
