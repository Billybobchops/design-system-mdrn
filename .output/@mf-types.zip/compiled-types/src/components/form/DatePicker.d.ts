interface DatePickerInputProps {
    label: string;
    helperText?: string;
    required: boolean;
}
declare const DatePickerInput: React.FC<DatePickerInputProps>;
export default DatePickerInput;
