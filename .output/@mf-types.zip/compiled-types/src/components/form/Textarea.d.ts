interface TextareaProps {
    disabled?: boolean;
    helperText?: string;
    label: string;
    name: string;
    required: boolean;
}
declare const Textarea: React.FC<TextareaProps>;
export default Textarea;
