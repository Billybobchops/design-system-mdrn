interface DateProviderProps {
    children?: React.ReactNode;
}
declare const DateProvider: React.FC<DateProviderProps>;
export default DateProvider;
