export * from './compiled-types/src/components/tabular/Tabs';
export { default } from './compiled-types/src/components/tabular/Tabs';