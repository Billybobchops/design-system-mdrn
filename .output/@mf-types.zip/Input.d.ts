export * from './compiled-types/src/components/form/Input';
export { default } from './compiled-types/src/components/form/Input';