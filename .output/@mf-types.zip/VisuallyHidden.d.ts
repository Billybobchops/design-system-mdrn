export * from './compiled-types/src/components/accessibility/VisuallyHidden';
export { default } from './compiled-types/src/components/accessibility/VisuallyHidden';