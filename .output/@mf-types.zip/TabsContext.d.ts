export * from './compiled-types/src/components/tabular/TabsContext';
export { default } from './compiled-types/src/components/tabular/TabsContext';