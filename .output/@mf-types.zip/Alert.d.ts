export * from './compiled-types/src/components/Alert';
export { default } from './compiled-types/src/components/Alert';