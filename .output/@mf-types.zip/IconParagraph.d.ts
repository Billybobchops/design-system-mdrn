export * from './compiled-types/src/components/typography/IconParagraph';
export { default } from './compiled-types/src/components/typography/IconParagraph';