export * from './compiled-types/src/components/button/SecondaryButton';
export { default } from './compiled-types/src/components/button/SecondaryButton';