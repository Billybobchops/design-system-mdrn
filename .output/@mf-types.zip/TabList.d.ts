export * from './compiled-types/src/components/tabular/TabList';
export { default } from './compiled-types/src/components/tabular/TabList';