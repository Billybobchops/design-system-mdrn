export * from './compiled-types/src/components/button/LinkIconButton';
export { default } from './compiled-types/src/components/button/LinkIconButton';